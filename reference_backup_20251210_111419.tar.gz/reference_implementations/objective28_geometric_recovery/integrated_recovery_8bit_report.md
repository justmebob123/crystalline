# Integrated Recovery Report

## Overall Statistics

- Total attempts: 20
- Successful recoveries: 0
- Overall success rate: 0.00%

## Success Rate by Bit Length

| Bit Length | Attempts | Successes | Success Rate |
|------------|----------|-----------|-------------|
| 8-bit | 20 | 0 | 0.00% |

## Anchor Tracking Statistics

- Average error: 129.250000
- Max error: 243.000000
- Min error: 12.000000
- Error std dev: 82.383175
- Global convergence: NO
- Global convergence rate: 0.000000
